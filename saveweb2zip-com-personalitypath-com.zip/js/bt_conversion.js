window.abst={};window.abst.timer=localStorage.absttimer===undefined?{}:JSON.parse(localStorage.absttimer||0);window.abst.currscroll=window.scrollY;window.abst.currentMousePos=-1;window.abst.oldMousePos=-2;window.abst.abactive=true;window.abst.timeoutTime=3000;window.abst.intervals={};jQuery(document).ready(function(){next_page_visit_report();if(!btab_vars.is_preview&&jQuery('.ab-test-page-redirect').length>0){jQuery('.ab-test-page-redirect').remove();}
if(jQuery('[bt_hidden="true"]').length>0){jQuery('[bt_hidden="true"]').remove();}
jQuery(document).mousemove(function(event){window.abst.currentMousePos=event.pageX;});jQuery('body').on('mousedown keydown touchstart',function(event){userActiveNow();});if(!('abConversionValue'in window))
window.abConversionValue=1;window.abst.timerInterval=setInterval(function(){if((window.abst.currscroll!=window.scrollY)||(window.abst.currentMousePos!=window.abst.oldMousePos))
{window.abst.currscroll=window.scrollY;window.abst.oldMousePos=window.abst.currentMousePos;userActiveNow();}
if(window.abst.abactive)
abstOneSecond();},1000);if(typeof conversion_details!=='undefined'&&conversion_details)
{var eid=null;var variation=null;page_url=window.location.href.replace(window.location.origin,'');if(page_url.charAt(0)=="/")page_url=page_url.substr(1);if(page_url.charAt(page_url.length-1)=="/")page_url=page_url.substr(0,page_url.length-1);jQuery.each(conversion_details,function(key,value){if(value.conversion_page_url&&page_url){var escapedUrl=value.conversion_page_url.replace(/([.+?^${}()|[\]\\])/g,'\\$1');var regexPattern=escapedUrl.replace(/\*/g,'.*');var regex=new RegExp(`^${regexPattern}$`);}
if(typeof regex!=='undefined'){if(regex.test(page_url)){eid=key;}}
else if((value.conversion_page_url===page_url)&&(value.conversion_page_url!==undefined)&&(value.conversion_page_url!=''))
{eid=key;}
else if(current_page.includes(value.conversion_page_id)||current_page.includes(parseInt(value.conversion_page_id)))
{eid=key;}
else
{return true;}
variation=getCookie('btab_'+eid);if(!variation)
return true;variation=JSON.parse(variation);if(variation.conversion==1)
return true;conversionValue=1;if(window.abConversionValue&&value.use_order_value==true)
conversionValue=window.abConversionValue;bt_experiment_w(eid,variation.variation,'conversion',false,conversionValue);});}
if(typeof bt_experiments!=='undefined')
{jQuery("[class^='ab-'],[class*=' ab-']").each(function(e){if(jQuery(this).attr('class').includes('ab-var-')||jQuery(this).attr('class').includes('ab-convert'))
{allClasses=jQuery(this).attr('class');allClasses=allClasses.split(" ");thisTestVar=false;thisTestId=false;thisTestConversion=false;allClasses.forEach(function(element){if(element.startsWith('ab-var-'))
thisTestVar=element;else if(element.startsWith('ab-')&&!element.includes('ab-convert'))
thisTestId=element;if(element=='ab-convert')
thisTestConversion=true;});if(thisTestVar!==false&&thisTestId!==false)
{jQuery(this).attr('bt-eid',thisTestId.replace("ab-",""));jQuery(this).attr('bt-variation',thisTestVar.replace("ab-var-",""));}
if(thisTestConversion==true&&thisTestId!==false)
{console.log('Element class conversion');abstConvert(thisTestId.replace("ab-",""));}}});jQuery("[data-bt-variation]").each(function(){jQuery(this).attr('bt-variation',jQuery(this).attr('data-bt-variation'));jQuery(this).attr('bt-eid',jQuery(this).attr('data-bt-eid'));});jQuery(".bricks-element [bt-eid]").each(function(e){jQuery(this).parents('.bricks-element').attr('bt-eid',jQuery(this).attr('bt-eid')).attr('bt-variation',jQuery(this).attr('bt-variation'));jQuery(this).removeAttr('bt-eid').removeAttr('bt-variation');});jQuery.each(bt_experiments,function(experimentId,experiment){if(experiment.test_winner&&(experiment.full_page_default_page==btab_vars.post_id))
{if(experiment.test_type=='full_page')
{if(experiment.test_winner!==btab_vars.post_id)
{if(experiment.page_variations[experiment.test_winner]==undefined)
{console.log('split test winner is not found, not redirecting');return false;}
console.log('Split Test winner is page redirect. Redirecting to '+experiment.page_variations[experiment.test_winner]);window.location.replace(experiment.page_variations[experiment.test_winner]+window.location.search);return false;}
else
{console.log('Test winner is current page. Showing '+experiment.test_winner);jQuery("body").addClass('abst-show-page');return false;}}
else if(experiment.test_type=='css_test')
{console.log('Split Test CSS winner. Showing '+experiment.test_winner);jQuery('body').addClass(experiment.test_winner);}
else
{console.log('Split Test winner is on this page. Showing '+experiment.test_winner);jQuery('*[bt-eid=\"'+experimentId+'\"][bt-variation=\"'+experiment.test_winner+'\"]').addClass('bt-show-variation');}
return true;}
if(experiment.test_type=="css_test")
{for(var i=0;i<experiment.css_test_variations;i++){jQuery('body').append('<script class="bt-css-scripts" bt-variation="test-css-'+experimentId+'-'+(i+1)+'" bt-eid="'+experimentId+'"/>');}}
if(experiment.test_type=='full_page'&&experiment.full_page_default_page==btab_vars.post_id)
{jQuery('body').append('<div class="bt-redirect-handle" style="display: none !important" bt-variation="'+experiment.full_page_default_page+'" bt-eid="'+experimentId+'"></div>');jQuery.each(experiment.page_variations,function(varId,variation){jQuery('body').append('<div class="bt-redirect-handle" style="display: none !important" bt-variation="'+varId+'" bt-eid="'+experimentId+'" bt-url="'+variation+'"></div>');});}
if(experiment.conversion_page=='selector')
{if(experiment.conversion_selector!='')
{var conversionSelector=experiment.conversion_selector;var eventType='click';if(conversionSelector.indexOf('|')!==-1){var conversionParts=conversionSelector.split('|');if(conversionParts.length>=2){conversionSelector=conversionParts[0];eventType=conversionParts[1];}}
var elements=document.querySelectorAll(conversionSelector);elements.forEach(function(element){element.addEventListener(eventType,function(event){console.log(eventType+' conversion on '+conversionSelector);abstConvert(experimentId);},true);});var iframes=document.querySelectorAll('iframe');iframes.forEach(function(iframe){var iframeDoc=iframe.contentWindow.document;var elementsInsideIframe=iframeDoc.querySelectorAll(conversionSelector);elementsInsideIframe.forEach(function(element){element.addEventListener(eventType,function(event){console.log(eventType+' conversion on '+conversionSelector);abstConvert(experimentId);},true);});});var allIframesAndContents=[];jQuery('iframe').each(function(){var iframe=jQuery(this);var iframeContents=iframe.contents().find('body').html();allIframesAndContents.push({iframe:iframe,contents:iframeContents});});console.log(allIframesAndContents);}}
if(experiment.conversion_page=='text')
{startInverval=true;if(!bt_experiments[experimentId])
startInverval=false;convstatus=getCookie('btab_'+experimentId);if(startInverval&&convstatus)
{convstatus=JSON.parse(convstatus);if(convstatus.conversion==1)
startInverval=false;}
if(experiment.conversion_text=='')
startInverval=false;if(startInverval)
{startTextWatcher(experimentId,experiment.conversion_text);}}
if(experiment.conversion_page=='surecart-order-paid'&&window.scData)
{document.addEventListener('scOrderPaid',function(e){console.log('surecart OrderPaid');const checkout=e.detail;if(checkout&&checkout.amount_due){if(experiment.use_order_value==true)
window.abConversionValue=checkout.amount_due;abstConvert(experimentId,window.abConversionValue);}});}});var experiments_el=jQuery('[bt-eid]:not([bt-eid=""])[bt-variation]:not([bt-variation=""])');var current_exp={};var exp_redirect={};experiments_el.each(function(e){var me=jQuery(this),experimentId=me.attr('bt-eid'),variation=me.attr('bt-variation'),redirect_url=me.attr('bt-url');if(current_exp[experimentId]===undefined){current_exp[experimentId]=[];exp_redirect[experimentId]=[];}
if(!current_exp[experimentId].includes(variation)){current_exp[experimentId].push(variation);exp_redirect[experimentId][variation]=redirect_url;}});jQuery.each(bt_experiments,function(experimentId,value){if(bt_experiments[experimentId]['test_type']=='css_test')
{current_exp[experimentId]=[];exp_redirect[experimentId]=[];for(var i=1;i<=parseInt(bt_experiments[experimentId]['css_test_variations']);i++){current_exp[experimentId].push('test-css-'+experimentId+'-'+i);exp_redirect[experimentId]['test-css-'+experimentId+'-'+i]='';}}});jQuery.each(current_exp,function(experimentId,variations){if(bt_experiments[experimentId]===undefined){console.log("ABST: "+'Test ID '+experimentId+' does not exist.');showSkippedVisitorDefault(experimentId);return true;}
if(bt_experiments[experimentId].test_winner)
return true;if('BorlabsCookie'in window)
if(!window.BorlabsCookie.checkCookieConsent('split-test')&&!window.BorlabsCookie.checkCookieConsent('ab-split-test'))
{console.log('Borlabs cookie consent prevented a split test from running');showSkippedVisitorDefault(experimentId);return true;}
if(bt_experiments[experimentId]['is_current_user_track']==false){showSkippedVisitorDefault(experimentId);return true;}
if(bt_experiments[experimentId]['test_status']!=='publish'){showSkippedVisitorDefault(experimentId);return true;}
var targetVisitor=true;var btab=getCookie('btab_'+experimentId);var experimentVariation='';if(!btab)
{if(bt_experiments[experimentId]['test_type']=='css_test'){var randVar=getRandomInt(1,parseInt(bt_experiments[experimentId]['css_test_variations']))-1;}
else
var randVar=getRandomInt(1,variations.length)-1;if(btab_vars.is_free&&variations.length>2){var randVar=getRandomInt(0,1);console.log('Free version of AB Split Test is limited to 1 variation. Your others will not be shown. Upgrade: https://absplittest.com/pricing?ref=ug');}
experimentVariation=variations[randVar];}
else
{var btab_cookie=JSON.parse(btab);experimentVariation=btab_cookie.variation;}
var variation_element=false;if(bt_experiments[experimentId]['test_type']=='css_test')
{jQuery('body').addClass(experimentVariation);}
else
{variation_element=jQuery('*[bt-eid=\"'+experimentId+'\"][bt-variation=\"'+experimentVariation+'\"]');}
if(btab){btab=JSON.parse(btab);var redirect_url=exp_redirect[experimentId][experimentVariation];if(redirect_url&&!btab_vars.is_preview){window.location.replace(redirect_url+window.location.search+window.location.hash);}
else
{abstShowPage();if(variation_element)
variation_element.addClass('bt-show-variation');}
return true;}
if(!btab){var targetPercentage=bt_experiments[experimentId].target_percentage;if(targetPercentage=='')
targetPercentage=100;var url_query=bt_experiments[experimentId].url_query;urlQueryResult=null;if(url_query!=='')
{var exploded_query=url_query.trim().split("=");if(exploded_query.length==1)
{targetVisitor=bt_getQueryVariable(exploded_query[0]);}
else if(exploded_query.length==2)
{urlQueryResult=bt_getQueryVariable(exploded_query[0]);targetVisitor=exploded_query[1]==urlQueryResult;}}
var target_option_device_size=bt_experiments[experimentId].target_option_device_size;if(targetVisitor&&target_option_device_size!='all')
{var device_size=jQuery(window).width();if(device_size>767)
device_size='desktop';else if(device_size>479)
device_size='tablet';else
device_size='mobile';targetVisitor=target_option_device_size.includes(device_size);}
if(!targetVisitor)
{showSkippedVisitorDefault(experimentId);return true;}
var percentage=getRandomInt(1,100);if(targetPercentage<percentage)
{showSkippedVisitorDefault(experimentId,true);console.log('ABST '+experimentId+' skipped not in percentage target');return true;}
bt_experiments[experimentId].variations=bt_get_variations(experimentId);}
if(variation_element&&!variation_element.length)
{showSkippedVisitorDefault(experimentId);console.log('ABST variation doesnt exist, or doesnt match');return true;}
if(Object.keys(exp_redirect).length>0)
{redirect_url=exp_redirect[experimentId];redirect_url=redirect_url[experimentVariation];}
else
redirect_url='';if(variation_element)
variation_element.addClass('bt-show-variation');bt_experiment_w(experimentId,experimentVariation,'visit',redirect_url);});}
if(btIsLocalhost())
console.info("AB Split Test: It looks like you're on a localhost, using local storage instead of cookies. External Conversion Pixels will not work on Local web servers.");window.dispatchEvent(new Event('resize'));jQuery('body').trigger('ab-test-setup-complete');});function startTextWatcher(experimentId,word){window.abst.intervals[experimentId]=setInterval(function(){let found=false;jQuery("body").find(":contains('"+word+"')").each(function(){if(jQuery(this).text().indexOf(word)>=0&&jQuery(this).is(":visible")){found=true;return false;}});if(!found){jQuery("iframe").each(function(){try{var iframeBody=jQuery(this).contents().find("body");found=iframeBody.find(":contains('"+word+"')").filter(function(){return jQuery(this).text().indexOf(word)>=0&&jQuery(this).is(":visible");}).length>0;if(found){console.log('ABST: '+experimentId+' '+word);return false;}}catch(error){}});}
if(found){abstConvert(experimentId);clearInterval(window.abst.intervals[experimentId]);}},1000);}
function abstConvert(testId='',orderValue=1){if(testId!=='')
{var btab=getCookie('btab_'+testId);if(btab)
{btab=JSON.parse(btab);if(btab.conversion==0)
{bt_experiment_w(testId,btab.variation,'conversion',false,orderValue);btab.conversion=1;experiment_vars=JSON.stringify(btab);setCookie('btab_'+testId,experiment_vars,1000);if(abst.intervals[testId]){clearInterval(abst.intervals[testId]);}}
else
{console.log("ABST: "+bt_experiments[testId].name+': Visitor has already converted');}}
else
{if(!bt_experiments[testId])
console.log("ABST: "+'Test ID not found or test not active');}}}
function showSkippedVisitorDefault(eid,createCookie=false){if(!window.bt_experiments[eid]){btv=jQuery('*[bt-eid=\"'+eid+'\"]').first().attr('bt-variation');jQuery('*[bt-eid=\"'+eid+'\"][bt-variation=\"'+btv+'\"]').addClass('bt-show-variation');return true;}
if(bt_experiments[eid].test_winner!==''){if(bt_experiments[eid].test_type=="full_page")
{url=bt_experiments[eid].page_variations[bt_experiments[eid].test_winner];if(url!==undefined)
{window.location.replace(url+window.location.search+window.location.hash);return true;}
else
{console.log("ABST: "+'Full page test complete without matching page winner. Showing current page.');}
abstShowPage();}
if(bt_experiments[eid].test_type=="css_test")
{console.log('css test winner, showing ver '+bt_experiments[eid]['test_winner']);jQuery("body").addClass('test-css-'+eid+'-'+bt_experiments[eid]['test_winner']);return true;}}
if(bt_experiments[eid].test_type=="full_page")
{abstShowPage();if(createCookie)
skippedCookie(eid,bt_experiments[eid].full_page_default_page);return true;}
if(bt_experiments[eid].test_type=="css_test")
{jQuery("body").addClass('test-css-'+eid+'-1');if(createCookie)
skippedCookie(eid,'test-css-'+eid+'-1');return true;}
var foundSpecial=false;if(!eid)
return;jQuery('*[bt-eid=\"'+eid+'\"]').each(function(index,element){var variationName=jQuery(element).attr('bt-variation').toLowerCase();var defaultNames=["original","one","1","default","standard","a","control"];if(defaultNames.includes(variationName))
{btv=variationName;jQuery(element).addClass('bt-show-variation');foundSpecial=true;}});if(!foundSpecial){btv=jQuery('*[bt-eid=\"'+eid+'\"]').first().attr('bt-variation');jQuery('*[bt-eid=\"'+eid+'\"][bt-variation=\"'+btv+'\"]').addClass('bt-show-variation');}
if(createCookie)
skippedCookie(eid,btv);}
function skippedCookie(eid,btv){var experiment_vars={eid:eid,variation:btv,conversion:1,skipped:1};experiment_vars=JSON.stringify(experiment_vars);setCookie('btab_'+eid,experiment_vars,1000);return true;}
function abstOneSecond(){if(Object.keys(window.abst.timer).length>0)
{Object.entries(window.abst.timer).forEach(([index,item])=>{if(window.abst.timer[index]>-1)
window.abst.timer[index]=window.abst.timer[index]-1;if(window.abst.timer[index]==0)
abstConvert(index);});localStorage.absttimer=JSON.stringify(window.abst.timer);}}
function userActiveNow(){window.abst.currscroll=window.scrollY;window.abst.abactive=true;clearTimeout(window.abst.timeoutTimer);window.abst.timeoutTimer=setTimeout(abstActiveTimeout,window.abst.timeoutTime);}
function abstActiveTimeout(){window.abst.abactive=false;}
function getRandomInt(min,max){min=Math.ceil(min);max=Math.floor(max);return Math.floor(Math.random()*(max-min+1))+min;}
function setCookie(c_name,value,exdays){if(btIsLocalhost())
return btSetLocal(c_name,value);var exdate=new Date();exdate.setDate(exdate.getDate()+exdays);var c_value=escape(value)+((exdays==null)?'':';path=/; expires='+exdate.toUTCString())+"; SameSite=None; Secure";document.cookie=c_name+'='+c_value;}
function deleteCookie(c_name){if(btIsLocalhost())
return btDeleteLocal(c_name);document.cookie=c_name+"= ; expires = Thu, 01 Jan 1970 00:00:00 GMT";}
function getCookie(c_name){if(btIsLocalhost())
return btGetLocal(c_name);var i,x,y,ARRcookies=document.cookie.split(';');for(i=0;i<ARRcookies.length;i++){x=ARRcookies[i].substr(0,ARRcookies[i].indexOf('='));y=ARRcookies[i].substr(ARRcookies[i].indexOf('=')+1);x=x.replace(/^\s+|\s+$/g,'');if(x==c_name){return unescape(y);}}}
function abstShowPage(){jQuery("body").addClass('abst-show-page');jQuery("body",parent.window.document).addClass('abst-show-page');}
function btSetLocal(c_name,value){localStorage.setItem(c_name,value);}
function btGetLocal(c_name){return localStorage.getItem(c_name);}
function btDeleteLocal(c_name){localStorage.removeItem(c_name);}
function btIsLocalhost(){return(location.hostname==="localhost"||location.hostname==="127.0.0.1"||location.hostname.endsWith(".local")||location.hostname.endsWith(".test"));}
function bt_get_variations(eid){variation=[];jQuery('[bt-eid='+eid+']').each(function(index,val){var newVariation=jQuery(this).attr('bt-variation');if(variation.indexOf(newVariation)===-1){variation.push(newVariation);}});if(btab_vars.is_free)
{variation=variation.slice(0,2);}
return variation;}
function bt_experiment_w(eid,variation,type,url,orderValue=1){if(variation=='_bt_skip_'||btab_vars.is_preview||!eid||!variation)
{return true;}
if(type=='visit'&&url){var nextPageVisitData={eid:eid,variation:variation,type:type,url:url,orderValue:orderValue};setCookie('ab-set-visit',JSON.stringify(nextPageVisitData),1000);window.location.replace(url+window.location.search+window.location.hash);return true;}
var data={'action':'bt_experiment_w','eid':eid,'variation':variation,'type':type,'location':btab_vars.post_id,'orderValue':orderValue};btab_track_event(data);var experiment_vars={eid:eid,variation:variation,conversion:0};if(type=='visit'&&bt_experiments[eid]['conversion_page']=='time')
{window.abst.timer[eid]=bt_experiments[eid]['conversion_time'];}
if(type=='conversion')
experiment_vars.conversion=1;experiment_vars=JSON.stringify(experiment_vars);setCookie('btab_'+eid,experiment_vars,1000);if(url!=="ex"&&!url)
{abstShowPage();}
jQuery.ajax({type:'POST',url:bt_ajaxurl,data:data,success:function(response){var res=JSON.parse(response);if(res.status===undefined||res.status!==0){console.log("ABST: "+eid+", "+variation+", "+type+' '+orderValue);}
if(type=='visit'&&res.status==0||btab_vars.is_preview){url=false;}},error:function(jqXHR,textStatus,errorThrown){console.log('ABST: AJAX error');console.log(jqXHR);console.log(textStatus);console.log(errorThrown);var experiment_vars={eid:eid,variation:variation,conversion:1,error:1,};experiment_vars=JSON.stringify(experiment_vars);setCookie('btab_'+eid,experiment_vars,1000);},complete:function(){if(url=="ex")
{}
else if(url)
{window.location.replace(url+window.location.search+window.location.hash);}}});return true;}
async function btab_track_event(data){if(btab_vars.tagging=='0'){return false;}
window.abeventstarted=new Date().getTime();var trackName=bt_experiments[data.eid].name;if(trackName=='')
trackName=data.eid;var trackCat=data.type;var trackValue=data.variation;window.abga4=setInterval(function(){if(typeof gtag==="function"){gtag('event','ab_split_test',{'test_name':trackName,'test_variation':trackValue,'test_event':trackCat});clearInterval(window.abga4);return;}
if(window.dataLayer&&typeof window.dataLayer.push==="function"){window.dataLayer.push({'event':'ab_split_test','test_name':trackName,'test_variation':trackValue,'test_event':trackCat});clearInterval(window.abga4);}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.abga4);},499);if(btab_vars.is_agency=='1')
{trackName="AB Test: "+trackName;var _paq=window._paq=window._paq||[];_paq.push(['trackEvent',trackName,trackCat,trackValue]);window.btclarity=setInterval(function(){if(typeof clarity==="function"){clarity("set",trackName+"-"+trackCat,trackValue);clearInterval(window.btclarity);}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.btclarity);},500);window.gai=setInterval(function(){if(typeof ga==="function"){tracker=ga.getAll()[0];if(tracker)
{tracker.send("event",trackName,trackCat,trackValue,{nonInteraction:true});clearInterval(window.gai);}}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.gai);},502);window.abmix=setInterval(function(){if(typeof mixpanel=="object"){mixpanel.track(trackName,{'type':trackCat,'variation':trackValue},{send_immediately:true});clearInterval(window.abmix);}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.abmix);},504);window.abumav=setInterval(function(){if(typeof usermaven==="function"){clearInterval(window.abumav);usermaven("track",bt_experiments[data.eid].name,{type:trackCat,variation:trackValue});}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.abumav);},493);window.abumami=setInterval(function(){if(window.umami){clearInterval(window.abumami);umami.track(bt_experiments[data.eid].name,{type:trackCat,variation:trackValue});}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.abumami);},496);window.abcabin=setInterval(function(){if(window.cabin){clearInterval(window.abcabin);cabin.event(bt_experiments[data.eid].name+' | '+trackCat+' | '+trackValue);}
if(new Date().getTime()-window.abeventstarted>5000)
clearInterval(window.abcabin);},505);window.plausible=window.plausible||function(){(window.plausible.q=window.plausible.q||[]).push(arguments);};plausible(bt_experiments[data.eid].name,{props:{testEvent:trackCat,variation:trackValue}});}}
function next_page_visit_report(){var setvisit=getCookie('ab-set-visit');if(setvisit)
{setvisit=JSON.parse(setvisit);bt_experiment_w(setvisit.eid,setvisit.variation,setvisit.type);setCookie('ab-set-visit',false,1000);}}
function bt_getQueryVariable(variable){var query=window.location.search.substring(1);var vars=query.split("&");for(var i=0;i<vars.length;i++){var pair=vars[i].split("=");if(pair[0]==variable){if(pair[1]==null)
return true;return pair[1];}}
return(false);}
if(!String.prototype.endsWith){String.prototype.endsWith=function(search,this_len){if(this_len===undefined||this_len>this.length){this_len=this.length;}
return this.substring(this_len-search.length,this_len)===search;};}